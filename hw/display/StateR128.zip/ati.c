/*
 * QEMU ATI SVGA emulation
 *
 * Copyright (c) 2019 BALATON Zoltan
 *
 * This work is licensed under the GNU GPL license version 2 or later.
 */

/*
 * WARNING:
 * This is very incomplete and only enough for Linux console and some
 * unaccelerated X output at the moment.
 * Currently it's little more than a frame buffer with minimal functions,
 * other more advanced features of the hardware are yet to be implemented.
 * We only aim for Rage 128 Pro (and some RV100) and 2D only at first,
 * No 3D at all yet (maybe after 2D works, but feel free to improve it)
 */

#include "qemu/osdep.h"
#include "ati_int.h"
#include "ati_regs.h"
#include "vga-access.h"
#include "hw/qdev-properties.h"
#include "vga_regs.h"
#include "qemu/bswap.h"
#include "qemu/log.h"
#include "qemu/module.h"
#include "qemu/error-report.h"
#include "qapi/error.h"
#include "ui/console.h"
#include "trace.h"

#define ATI_DEBUG_HW_CURSOR 0

#ifdef CONFIG_PIXMAN
#define DEFAULT_X_PIXMAN 3
#else
#define DEFAULT_X_PIXMAN 0
#endif

static const struct {
    const char *name;
    uint16_t dev_id;
} ati_model_aliases[] = {
    { "rage128p", PCI_DEVICE_ID_ATI_RAGE128_PF },
    { "rv100", PCI_DEVICE_ID_ATI_RADEON_QY },
};

enum { VGA_MODE, EXT_MODE };

static void ati_vga_set_offset(VGACommonState *vga, uint32_t offs)
{
    int bypp = DIV_ROUND_UP(vga->vbe_regs[VBE_DISPI_INDEX_BPP], BITS_PER_BYTE);

    if (!bypp ||
        vga->vbe_regs[VBE_DISPI_INDEX_YRES] *
        vga->vbe_regs[VBE_DISPI_INDEX_VIRT_WIDTH] * bypp + offs >
        vga->vbe_size) {
        return;
    }
    vga->vbe_start_addr = offs / 4;
}

static void ati_vga_switch_mode(ATIVGAState *s)
{
    DPRINTF("%d -> %d\n",
            s->mode, !!(s->regs.crtc_gen_cntl & CRTC2_EXT_DISP_EN));
    if (s->regs.crtc_gen_cntl & CRTC2_EXT_DISP_EN) {
        /* Extended mode enabled */
        s->mode = EXT_MODE;
        if (s->regs.crtc_gen_cntl & CRTC2_EN) {
            /* CRT controller enabled, use CRTC values */
            /* FIXME Should these be the same as VGA CRTC regs? */
            uint32_t offs = s->regs.crtc_offset & 0x07ffffff;
            int stride = (s->regs.crtc_pitch & 0x7ff) * 8;
            int bpp = 0;
            int h, v;

            if (s->regs.crtc_h_total_disp == 0) {
                s->regs.crtc_h_total_disp = ((640 / 8) - 1) << 16;
            }
            if (s->regs.crtc_v_total_disp == 0) {
                s->regs.crtc_v_total_disp = (480 - 1) << 16;
            }
            h = ((s->regs.crtc_h_total_disp >> 16) + 1) * 8;
            v = (s->regs.crtc_v_total_disp >> 16) + 1;
            switch (s->regs.crtc_gen_cntl & CRTC_PIX_WIDTH_MASK) {
            case CRTC_PIX_WIDTH_4BPP:
                bpp = 4;
                break;
            case CRTC_PIX_WIDTH_8BPP:
                bpp = 8;
                break;
            case CRTC_PIX_WIDTH_15BPP:
                bpp = 15;
                break;
            case CRTC_PIX_WIDTH_16BPP:
                bpp = 16;
                break;
            case CRTC_PIX_WIDTH_24BPP:
                bpp = 24;
                break;
            case CRTC_PIX_WIDTH_32BPP:
                bpp = 32;
                break;
            default:
                qemu_log_mask(LOG_UNIMP, "Unsupported bpp value\n");
                return;
            }
            DPRINTF("Switching to %dx%d %d %d @ %x\n", h, v, stride, bpp, offs);
            vbe_ioport_write_index(&s->vga, 0, VBE_DISPI_INDEX_ENABLE);
            vbe_ioport_write_data(&s->vga, 0, VBE_DISPI_DISABLED);
            s->vga.big_endian_fb = (s->regs.config_cntl & APER_0_ENDIAN ||
                                    s->regs.config_cntl & APER_1_ENDIAN ?
                                    true : false);
            /* reset VBE regs then set up mode */
            s->vga.vbe_regs[VBE_DISPI_INDEX_XRES] = h;
            s->vga.vbe_regs[VBE_DISPI_INDEX_YRES] = v;
            s->vga.vbe_regs[VBE_DISPI_INDEX_BPP] = bpp;
            /* enable mode via ioport so it updates vga regs */
            vbe_ioport_write_index(&s->vga, 0, VBE_DISPI_INDEX_ENABLE);
            vbe_ioport_write_data(&s->vga, 0, VBE_DISPI_ENABLED |
                VBE_DISPI_LFB_ENABLED | VBE_DISPI_NOCLEARMEM |
                (s->regs.dac_cntl & DAC_8BIT_EN ? VBE_DISPI_8BIT_DAC : 0));
            /* now set offset and stride because enable resets these */
            if (stride) {
                vbe_ioport_write_index(&s->vga, 0, VBE_DISPI_INDEX_VIRT_WIDTH);
                vbe_ioport_write_data(&s->vga, 0, stride);
            }
            ati_vga_set_offset(&s->vga, offs);
        }
    } else {
        /* VGA mode enabled */
        s->mode = VGA_MODE;
        vbe_ioport_write_index(&s->vga, 0, VBE_DISPI_INDEX_ENABLE);
        vbe_ioport_write_data(&s->vga, 0, VBE_DISPI_DISABLED);
    }
}

/* Used by host side hardware cursor */
static void ati_cursor_define(ATIVGAState *s)
{
    uint64_t data[128];
    uint32_t srcoff;

    if ((s->regs.cur_offset & BIT(31)) || s->cursor_guest_mode) {
        return; /* Do not update cursor if locked or rendered by guest */
    }
    /* FIXME handle cur_hv_offs correctly */
    srcoff = (s->regs.cur_offset & 0x07fffff0) - (s->regs.cur_hv_offs >> 16) -
             (s->regs.cur_hv_offs & 0xffff) * 16;
    if (srcoff > s->vga.vram_size - 64 * 16) {
        return;
    }
    for (int i = 0; i < 64; i++, srcoff += 16) {
        data[i] = ldq_le_p(&s->vga.vram_ptr[srcoff]);
        data[i + 64] = ldq_le_p(&s->vga.vram_ptr[srcoff + 8]);
    }
    if (!s->cursor) {
        s->cursor = cursor_alloc(64, 64);
    }
    cursor_set_mono(s->cursor, s->regs.cur_color1, s->regs.cur_color0,
                    (uint8_t *)&data[64], 1, (uint8_t *)&data[0]);
    dpy_cursor_define(s->vga.con, s->cursor);
}

/* Alternatively support guest rendered hardware cursor */
static void ati_cursor_invalidate(VGACommonState *vga)
{
    ATIVGAState *s = container_of(vga, ATIVGAState, vga);
    int size = (s->regs.crtc_gen_cntl & CRTC2_CUR_EN) ? 64 : 0;

    if (s->regs.cur_offset & BIT(31)) {
        return; /* Do not update cursor if locked */
    }
    if (s->cursor_size != size ||
        vga->hw_cursor_x != s->regs.cur_hv_pos >> 16 ||
        vga->hw_cursor_y != (s->regs.cur_hv_pos & 0xffff) ||
        s->cursor_offset != (s->regs.cur_offset & 0x07fffff0) -
        (s->regs.cur_hv_offs >> 16) -
        (s->regs.cur_hv_offs & 0xffff) * 16) {
        /* Remove old cursor then update and show new one if needed */
        vga_invalidate_scanlines(vga, vga->hw_cursor_y, vga->hw_cursor_y + 63);
        vga->hw_cursor_x = s->regs.cur_hv_pos >> 16;
        vga->hw_cursor_y = s->regs.cur_hv_pos & 0xffff;
        s->cursor_offset = (s->regs.cur_offset & 0x07fffff0) -
                           (s->regs.cur_hv_offs >> 16) -
                           (s->regs.cur_hv_offs & 0xffff) * 16;
        s->cursor_size = size;
        if (size) {
            vga_invalidate_scanlines(vga,
                                     vga->hw_cursor_y, vga->hw_cursor_y + 63);
        }
    }
}

static void ati_cursor_draw_line(VGACommonState *vga, uint8_t *d, int scr_y)
{
    ATIVGAState *s = container_of(vga, ATIVGAState, vga);
    uint32_t h, srcoff, color;
    uint64_t abits, xbits, mask;
    uint32_t *dp = (uint32_t *)d;

    if (!(s->regs.crtc_gen_cntl & CRTC2_CUR_EN) ||
        scr_y < vga->hw_cursor_y || scr_y >= vga->hw_cursor_y + 64 ||
        scr_y > s->regs.crtc_v_total_disp >> 16) {
        return;
    }
    /* FIXME handle cur_hv_offs correctly */
    srcoff = s->cursor_offset + (scr_y - vga->hw_cursor_y) * 16;
    if (srcoff > s->vga.vram_size - 16) {
        return;
    }
    dp = &dp[vga->hw_cursor_x];
    h = ((s->regs.crtc_h_total_disp >> 16) + 1) * 8;
    abits = ldq_be_p(&vga->vram_ptr[srcoff]);
    xbits = ldq_be_p(&vga->vram_ptr[srcoff + 8]);
    mask = BIT_ULL(63);
    for (int i = 0; i < 64; i++, mask >>= 1) {
        if (vga->hw_cursor_x + i >= h) {
            return; /* end of screen, don't span to next line */
        }
        if (abits & mask) {
            if (xbits & mask) {
                color = dp[i] ^ 0xffffffff; /* complement */
            } else {
                continue; /* transparent, no change */
            }
        } else {
            color = (xbits & mask ? s->regs.cur_color1 :
                                    s->regs.cur_color0) | 0xff000000;
        }
        dp[i] = color;
    }
}

static uint64_t ati_i2c(bitbang_i2c_interface *i2c, uint64_t data, int base)
{
    bool c = (data & BIT(base + 17) ? !!(data & BIT(base + 1)) : 1);
    bool d = (data & BIT(base + 16) ? !!(data & BIT(base)) : 1);

    bitbang_i2c_set(i2c, BITBANG_I2C_SCL, c);
    d = bitbang_i2c_set(i2c, BITBANG_I2C_SDA, d);

    data &= ~0xf00ULL;
    if (c) {
        data |= BIT(base + 9);
    }
    if (d) {
        data |= BIT(base + 8);
    }
    return data;
}

static void ati_vga_update_irq(ATIVGAState *s)
{
    pci_set_irq(&s->dev, !!(s->regs.gen_int_status & s->regs.gen_int_cntl));
}

static void ati_vga_vblank_irq(void *opaque)
{
    ATIVGAState *s = opaque;

    {
        static int64_t last;
        static unsigned n;
        int64_t now = qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL);

        if (n < 40) {
            n++;
            qemu_log("ati_vblank: t=%" PRId64 " delta=%" PRId64 " us "
                     "status=0x%x cntl=0x%x\n",
                     now, last ? (now - last) / 1000 : 0,
                     s->regs.gen_int_status, s->regs.gen_int_cntl);
        }
        last = now;
    }

    timer_mod(&s->vblank_timer, qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL) +
              NANOSECONDS_PER_SECOND / 60);

    /*
     * Do not stack interrupts. If the previous vblank has not been
     * acknowledged yet, leave the status alone rather than asserting
     * again: real hardware raises one edge per frame, and re-raising on
     * top of an unserviced interrupt turns a handler that is merely slow
     * into a livelock - the guest acknowledges, a new interrupt is already
     * pending on the next read, and it never returns to normal execution.
     *
     * Mac OS 9 with the ATI Resource Manager shows exactly that trace:
     * write 0x44 <- 0x1 immediately followed by read 0x44 -> 0x1.
     */
    if (s->regs.gen_int_status & CRTC_VBLANK_INT) {
        return;
    }
    s->regs.gen_int_status |= CRTC_VBLANK_INT;
    ati_vga_update_irq(s);
}

static inline uint32_t ati_reg_read_offs(uint32_t reg, int offs,
                                         unsigned int size)
{
    if (offs == 0 && size == 4) {
        return reg;
    } else {
        return extract32(reg, offs * BITS_PER_BYTE, size * BITS_PER_BYTE);
    }
}

static uint64_t ati_mm_read(void *opaque, hwaddr addr, unsigned int size)
{
    ATIVGAState *s = opaque;
    uint32_t val = 0;

    switch (addr) {
    case MM_INDEX:
        val = s->regs.mm_index;
        break;
    case MM_DATA ... MM_DATA + 3:
        /* indexed access to regs or memory */
        if (s->regs.mm_index & BIT(31)) {
            uint32_t idx = s->regs.mm_index & ~BIT(31);
            if (idx <= s->vga.vram_size - size) {
                val = ldn_le_p(s->vga.vram_ptr + idx, size);
            }
        } else if (s->regs.mm_index > MM_DATA + 3) {
            val = ati_mm_read(s, s->regs.mm_index + addr - MM_DATA, size);
        } else {
            qemu_log_mask(LOG_GUEST_ERROR,
                "ati_mm_read: mm_index too small: %u\n", s->regs.mm_index);
        }
        break;
    case BIOS_0_SCRATCH ... BUS_CNTL - 1:
    {
        int i = (addr - BIOS_0_SCRATCH) / 4;
        if (s->dev_id == PCI_DEVICE_ID_ATI_RAGE128_PF && i > 3) {
            break;
        }
        val = ati_reg_read_offs(s->regs.bios_scratch[i],
                                addr - (BIOS_0_SCRATCH + i * 4), size);
        break;
    }
    case CLOCK_CNTL_INDEX:
        val = s->regs.clock_cntl_index;
        break;
    case CLOCK_CNTL_DATA:
        /*
         * Indexed PLL window: CLOCK_CNTL_INDEX selects a PLL register and
         * CLOCK_CNTL_DATA reads or writes it. Neither was implemented, so
         * every PLL read returned 0 and Mac OS 9 spun selecting index 3
         * (PPLL_REF_DIV) and reading back nothing.
         */
        val = s->regs.pll[s->regs.clock_cntl_index & 0x3f];
        break;
    case AMCGPIO_Y_MIR:
        /*
         * GPIO input mirror - the value sampled from the pins.
         *
         * This had no case at all, so it returned 0 on all 105310 reads
         * of one boot: both I2C lines reading low, which on a real bus
         * means somebody is holding it down. Mac OS 9 bit-bangs DDC here
         * (211378 toggles of I2C_CNTL_1 in the same boot) and retries
         * forever against a bus that never releases.
         *
         * Idle I2C is pulled HIGH. Report any line we are not actively
         * driving low as high, so the guest sees a free bus, gets no
         * acknowledge from a device that is not there, and concludes there
         * is no monitor on this port instead of spinning.
         */
        val = (s->regs.amcgpio_a_mir & s->regs.amcgpio_en_mir) |
              ~s->regs.amcgpio_en_mir;
        break;
    case AMCGPIO_A_MIR:
        val = s->regs.amcgpio_a_mir;
        break;
    case AMCGPIO_EN_MIR:
        val = s->regs.amcgpio_en_mir;
        break;
    case AMCGPIO_MASK_MIR:
        val = s->regs.amcgpio_mask_mir;
        break;
    case I2C_CNTL_1:
        /*
         * I2C/DDC control. r128_reg.h documents the address but no bits
         * (it is marked "?"), so this is behaviour-driven rather than
         * decoded: Mac OS 9 writes 0x10000 - a go/start bit - then reads
         * back waiting for the transaction to change state. Returning 0
         * meant it never started and never finished, and the guest retried
         * 211378 times in one boot while the Finder waited on display
         * detection.
         *
         * We have no monitor on the far end, so hold the written value.
         * The write-then-verify completes and the probe moves on to
         * finding no device, rather than spinning forever.
         */
        val = s->regs.i2c_cntl_1;
        break;
    case FP_GEN_CNTL:
        /*
         * Flat panel control. Not previously implemented, so it read back
         * as 0 and a write-then-verify never completed: Mac OS 9 wrote
         * 0x200 and spun waiting to read it back. Plain storage is enough
         * - nothing here drives real panel hardware.
         */
        val = s->regs.fp_gen_cntl;
        break;
    case GEN_INT_CNTL:
        val = s->regs.gen_int_cntl;
        break;
    case GEN_INT_STATUS:
        val = s->regs.gen_int_status;
        break;
    case CRTC_GEN_CNTL ... CRTC_GEN_CNTL + 3:
        val = ati_reg_read_offs(s->regs.crtc_gen_cntl,
                                addr - CRTC_GEN_CNTL, size);
        break;
    case CRTC_EXT_CNTL ... CRTC_EXT_CNTL + 3:
        val = ati_reg_read_offs(s->regs.crtc_ext_cntl,
                                addr - CRTC_EXT_CNTL, size);
        break;
    case DAC_CNTL:
        val = s->regs.dac_cntl;
        break;
    case GPIO_VGA_DDC ... GPIO_VGA_DDC + 3:
        val = ati_reg_read_offs(s->regs.gpio_vga_ddc,
                                addr - GPIO_VGA_DDC, size);
        break;
    case GPIO_DVI_DDC ... GPIO_DVI_DDC + 3:
        val = ati_reg_read_offs(s->regs.gpio_dvi_ddc,
                                addr - GPIO_DVI_DDC, size);
        break;
    case GPIO_MONID ... GPIO_MONID + 3:
        val = ati_reg_read_offs(s->regs.gpio_monid,
                                addr - GPIO_MONID, size);
        break;
    case PALETTE_INDEX:
        /* FIXME unaligned access */
        val = vga_ioport_read(&s->vga, VGA_PEL_IR) << 16;
        val |= vga_ioport_read(&s->vga, VGA_PEL_IW) & 0xff;
        break;
    case PALETTE_DATA:
        val = vga_ioport_read(&s->vga, VGA_PEL_D);
        break;
    case PALETTE_30_DATA:
        val = s->regs.palette[vga_ioport_read(&s->vga, VGA_PEL_IR)];
        break;
    case CNFG_CNTL:
        val = s->regs.config_cntl;
        break;
    case CNFG_MEMSIZE:
        val = s->vga.vram_size;
        break;
    case CONFIG_APER_0_BASE:
        val = pci_default_read_config(&s->dev,
                                      PCI_BASE_ADDRESS_0, size) & 0xfffffff0;
        break;
    case CONFIG_APER_1_BASE:
        /*
         * Aperture 1 sits immediately above aperture 0 in the same BAR.
         * Reporting the BAR base here (as aperture 0) made the guest driver
         * compute the wrong framebuffer address.
         */
        val = (pci_default_read_config(&s->dev,
                                       PCI_BASE_ADDRESS_0, size) & 0xfffffff0)
              + memory_region_size(&s->linear_aper) / 2;
        break;
    case PCI_GART_PAGE:
        val = s->regs.pci_gart_page;
        break;
    case MC_AGP_LOCATION:
        val = s->regs.mc_agp_location;
        break;
    case MC_FB_LOCATION:
        val = s->regs.mc_fb_location;
        break;
    case PM4_IW_INDOFF:
        val = s->cce.iw_indoff;
        break;
    case CONFIG_APER_SIZE:
        val = memory_region_size(&s->linear_aper) / 2;
        break;
    case CONFIG_REG_1_BASE:
        val = pci_default_read_config(&s->dev,
                                      PCI_BASE_ADDRESS_2, size) & 0xfffffff0;
        break;
    case CONFIG_REG_APER_SIZE:
        val = memory_region_size(&s->mm) / 2;
        break;
    case HOST_PATH_CNTL:
        val = BIT(23); /* Radeon HDP_APER_CNTL */
        break;
    case MEM_CNTL:
        /*
         * Read back what the guest programmed. The Mac OS X NDRV writes a
         * memory controller configuration here and reads it back; returning
         * zero made it fall through to a default configuration and mis-size
         * video memory. The field encoding is not modelled - this only makes
         * the register behave as storage, which is what the readback needs.
         */
        val = s->regs.mem_cntl;
        break;
    case MC_STATUS:
        val = 5;
        break;
    case MEM_SDRAM_MODE_REG:
        if (s->dev_id != PCI_DEVICE_ID_ATI_RAGE128_PF) {
            val = BIT(28) | BIT(20);
        }
        break;
    case RBBM_STATUS:
    case GUI_STAT:
        val = 64; /* free CMDFIFO entries */
        break;
    case PC_GUI_CTLSTAT:
    case PC_NGUI_CTLSTAT:
        /*
         * Pixel cache control/status. The guest sets PC_FLUSH_ALL (0xff)
         * and then polls until PC_BUSY (bit 31) clears; we flush
         * synchronously, so report the request bits back with PC_BUSY
         * already low.
         *
         * Without a read case here this returned 0, so a flush looked as
         * though it had never been accepted. Mac OS 9 with the ATI
         * Resource Manager extension hangs on exactly this: the extension
         * is what brings the CCE up, that path calls wait-for-idle ->
         * pixcache flush, and the poll never completes. Booting without
         * the extension never touches it, which is why only that
         * configuration froze.
         */
        val = s->regs.pc_gui_ctlstat & ~PC_BUSY;
        break;
    case CRTC_H_TOTAL_DISP ... CRTC_H_TOTAL_DISP + 3:
        val = ati_reg_read_offs(s->regs.crtc_h_total_disp,
                                addr - CRTC_H_TOTAL_DISP, size);
        break;
    case CRTC_H_SYNC_STRT_WID:
        val = s->regs.crtc_h_sync_strt_wid;
        break;
    case CRTC_V_TOTAL_DISP ... CRTC_V_TOTAL_DISP + 3:
        val = ati_reg_read_offs(s->regs.crtc_v_total_disp,
                                addr - CRTC_V_TOTAL_DISP, size);
        break;
    case CRTC_V_SYNC_STRT_WID:
        val = s->regs.crtc_v_sync_strt_wid;
        break;
    case CRTC_OFFSET:
        val = s->regs.crtc_offset;
        break;
    case CRTC_OFFSET_CNTL:
        val = s->regs.crtc_offset_cntl;
        break;
    case CRTC_PITCH:
        val = s->regs.crtc_pitch;
        break;
    case 0xf00 ... 0xfff:
        val = pci_default_read_config(&s->dev, addr - 0xf00, size);
        break;
    case CUR_OFFSET ... CUR_OFFSET + 3:
        val = ati_reg_read_offs(s->regs.cur_offset, addr - CUR_OFFSET, size);
        break;
    case CUR_HORZ_VERT_POSN ... CUR_HORZ_VERT_POSN + 3:
        val = ati_reg_read_offs(s->regs.cur_hv_pos,
                                addr - CUR_HORZ_VERT_POSN, size);
        if (addr + size > CUR_HORZ_VERT_POSN + 3) {
            val |= (s->regs.cur_offset & BIT(31)) >> (4 - size);
        }
        break;
    case CUR_HORZ_VERT_OFF ... CUR_HORZ_VERT_OFF + 3:
        val = ati_reg_read_offs(s->regs.cur_hv_offs,
                                addr - CUR_HORZ_VERT_OFF, size);
        if (addr + size > CUR_HORZ_VERT_OFF + 3) {
            val |= (s->regs.cur_offset & BIT(31)) >> (4 - size);
        }
        break;
    case CUR_CLR0 ... CUR_CLR0 + 3:
        val = ati_reg_read_offs(s->regs.cur_color0, addr - CUR_CLR0, size);
        break;
    case CUR_CLR1 ... CUR_CLR1 + 3:
        val = ati_reg_read_offs(s->regs.cur_color1, addr - CUR_CLR1, size);
        break;
    case DST_OFFSET:
        val = s->regs.dst_offset;
        break;
    case DST_PITCH:
        val = s->regs.dst_pitch;
        if (s->dev_id == PCI_DEVICE_ID_ATI_RAGE128_PF) {
            val |= s->regs.dst_tile << 16;
        }
        break;
    case DST_WIDTH:
        val = s->regs.dst_width;
        break;
    case DST_HEIGHT:
        val = s->regs.dst_height;
        break;
    case SRC_X:
        val = s->regs.src_x;
        break;
    case SRC_Y:
        val = s->regs.src_y;
        break;
    case DST_X:
        val = s->regs.dst_x;
        break;
    case DST_Y:
        val = s->regs.dst_y;
        break;
    case DP_GUI_MASTER_CNTL:
    case DP_GUI_MASTER_CNTL_C:
        /* DP_GUI_MASTER_CNTL aliases fields from DP_MIX and DP_DATATYPE */
        val = s->regs.dp_gui_master_cntl |
              ((s->regs.dp_datatype & DP_BRUSH_DATATYPE) >> 4) |
              ((s->regs.dp_datatype & DP_DST_DATATYPE) << 8) |
              ((s->regs.dp_datatype & DP_SRC_DATATYPE) >> 4) |
              (s->regs.dp_mix & DP_ROP3) |
              ((s->regs.dp_mix & DP_SRC_SOURCE) << 16);
        break;
    case SRC_OFFSET:
        val = s->regs.src_offset;
        break;
    case SRC_PITCH:
        val = s->regs.src_pitch;
        if (s->dev_id == PCI_DEVICE_ID_ATI_RAGE128_PF) {
            val |= s->regs.src_tile << 16;
        }
        break;
    case DP_BRUSH_BKGD_CLR:
        val = s->regs.dp_brush_bkgd_clr;
        break;
    case DP_BRUSH_FRGD_CLR:
        val = s->regs.dp_brush_frgd_clr;
        break;
    case DP_SRC_FRGD_CLR:
        val = s->regs.dp_src_frgd_clr;
        break;
    case DP_SRC_BKGD_CLR:
        val = s->regs.dp_src_bkgd_clr;
        break;
    case GUI_SCRATCH_REG0 ... GUI_SCRATCH_REG5 + 3:
    {
        int i = (addr - GUI_SCRATCH_REG0) / 4;

        val = ati_reg_read_offs(s->regs.gui_scratch[i],
                                addr - (GUI_SCRATCH_REG0 + i * 4), size);
        break;
    }
    case DP_CNTL:
        val = s->regs.dp_cntl;
        break;
    case DP_DATATYPE:
        val = s->regs.dp_datatype;
        break;
    case DP_MIX:
        val = s->regs.dp_mix;
        break;
    case DP_WRITE_MASK:
        val = s->regs.dp_write_mask;
        break;
    case DEFAULT_OFFSET:
        val = s->regs.default_offset;
        if (s->dev_id != PCI_DEVICE_ID_ATI_RAGE128_PF) {
            val >>= 10;
            val |= s->regs.default_pitch << 16;
            val |= s->regs.default_tile << 30;
        }
        break;
    case DEFAULT_PITCH:
        val = s->regs.default_pitch;
        val |= s->regs.default_tile << 16;
        break;
    case DEFAULT_SC_BOTTOM_RIGHT:
        val = s->regs.default_sc_right;
        val |= s->regs.default_sc_bottom << 16;
        break;
    case SC_TOP:
        val = s->regs.sc_top;
        break;
    case SC_LEFT:
        val = s->regs.sc_left;
        break;
    case SC_BOTTOM:
        val = s->regs.sc_bottom;
        break;
    case SC_RIGHT:
        val = s->regs.sc_right;
        break;
    case SRC_SC_BOTTOM:
        val = s->regs.src_sc_bottom;
        break;
    case SRC_SC_RIGHT:
        val = s->regs.src_sc_right;
        break;
    case SC_TOP_LEFT:
    case SC_TOP_LEFT_C:
    case SC_BOTTOM_RIGHT:
    case SC_BOTTOM_RIGHT_C:
    case SRC_SC_BOTTOM_RIGHT:
        qemu_log_mask(LOG_GUEST_ERROR,
                      "Read from write-only register 0x%x\n", (unsigned)addr);
        break;
    case PM4_BUFFER_OFFSET:
        val = s->cce.buffer_offset;
        break;
    case PM4_BUFFER_CNTL:
        val = s->cce.buffer_cntl;
        break;
    case PM4_BUFFER_DL_RPTR:
        val = s->cce.rptr;
        break;
    case PM4_BUFFER_DL_WPTR:
        val = s->cce.wptr;
        break;
    case PM4_STAT:
        /*
         * We drain the ring synchronously in ati_cce_process(), so from
         * the guest's point of view the engine is always caught up and
         * idle by the time it gets to check status: full FIFO free
         * count, not busy, not GUI-active.
         */
        val = PM4_STAT_FIFOCNT_MASK;
        break;
    default:
        break;
    }
    if (addr < CUR_OFFSET || addr > CUR_CLR1 || ATI_DEBUG_HW_CURSOR) {
        trace_ati_mm_read(size, addr, ati_reg_name(addr & ~3ULL), val);
    }
    return val;
}

static inline void ati_reg_write_offs(uint32_t *reg, int offs,
                                      uint64_t data, unsigned int size)
{
    if (offs == 0 && size == 4) {
        *reg = data;
    } else {
        *reg = deposit32(*reg, offs * BITS_PER_BYTE, size * BITS_PER_BYTE,
                         data);
    }
}

void ati_mm_write(void *opaque, hwaddr addr,
                    uint64_t data, unsigned int size)
{
    ATIVGAState *s = opaque;

    if (addr < CUR_OFFSET || addr > CUR_CLR1 || ATI_DEBUG_HW_CURSOR) {
        trace_ati_mm_write(size, addr, ati_reg_name(addr & ~3ULL), data);
    }
    switch (addr) {
    case MM_INDEX:
        s->regs.mm_index = data & ~3;
        break;
    case MM_DATA ... MM_DATA + 3:
        /* indexed access to regs or memory */
        if (s->regs.mm_index & BIT(31)) {
            uint32_t idx = s->regs.mm_index & ~BIT(31);
            if (idx <= s->vga.vram_size - size) {
                stn_le_p(s->vga.vram_ptr + idx, size, data);
            }
        } else if (s->regs.mm_index > MM_DATA + 3) {
            ati_mm_write(s, s->regs.mm_index + addr - MM_DATA, data, size);
        } else {
            qemu_log_mask(LOG_GUEST_ERROR,
                "ati_mm_write: mm_index too small: %u\n", s->regs.mm_index);
        }
        break;
    case BIOS_0_SCRATCH ... BUS_CNTL - 1:
    {
        int i = (addr - BIOS_0_SCRATCH) / 4;
        if (s->dev_id == PCI_DEVICE_ID_ATI_RAGE128_PF && i > 3) {
            break;
        }
        ati_reg_write_offs(&s->regs.bios_scratch[i],
                           addr - (BIOS_0_SCRATCH + i * 4), data, size);
        break;
    }
    case CLOCK_CNTL_INDEX:
        s->regs.clock_cntl_index = data;
        break;
    case CLOCK_CNTL_DATA:
        /* Bit 7 of the index is the write-enable strobe on this part. */
        s->regs.pll[s->regs.clock_cntl_index & 0x3f] = data;
        break;
    case AMCGPIO_A_MIR:
        s->regs.amcgpio_a_mir = data;
        break;
    case AMCGPIO_EN_MIR:
        s->regs.amcgpio_en_mir = data;
        break;
    case AMCGPIO_MASK_MIR:
        s->regs.amcgpio_mask_mir = data;
        break;
    case AMCGPIO_Y_MIR:
        break;                  /* input only */
    case I2C_CNTL_1:
        s->regs.i2c_cntl_1 = data;
        break;
    case FP_GEN_CNTL:
        s->regs.fp_gen_cntl = data;
        break;
    case GEN_INT_CNTL:
        s->regs.gen_int_cntl = data;
        /*
         * Arm on bit 0. The guest only ever writes 0x1 and 0x401 here, so
         * requiring R128_VSYNC_INT (bit 2) meant the timer never started:
         * no vblank interrupts at all, which stops the Mac OS 9 clock and
         * freezes the cursor while the rest of the system keeps running.
         */
        if (data & CRTC_VBLANK_INT) {
            /*
             * Arm the timer only - do NOT call ati_vga_vblank_irq() here.
             * That raises the status bit and asserts the line immediately,
             * so enabling interrupts synthesised one on the spot. A driver
             * that re-enables inside its handler then took another at
             * once, and Mac OS 9 spun in its interrupt handler forever:
             * the acknowledge looked as though it never worked, because a
             * fresh interrupt arrived before the next read.
             */
            timer_mod(&s->vblank_timer,
                      qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL) +
                      NANOSECONDS_PER_SECOND / 60);
        } else {
            timer_del(&s->vblank_timer);
        }
        ati_vga_update_irq(s);
        break;
    case GEN_INT_STATUS:
        data &= (s->dev_id == PCI_DEVICE_ID_ATI_RAGE128_PF ?
                 0x000f040fUL : 0xfc080effUL);
        s->regs.gen_int_status &= ~data;
        ati_vga_update_irq(s);
        break;
    case CRTC_GEN_CNTL ... CRTC_GEN_CNTL + 3:
    {
        uint32_t val = s->regs.crtc_gen_cntl;
        ati_reg_write_offs(&s->regs.crtc_gen_cntl,
                           addr - CRTC_GEN_CNTL, data, size);
        if ((val & CRTC2_CUR_EN) != (s->regs.crtc_gen_cntl & CRTC2_CUR_EN)) {
            ati_vga_switch_mode(s);
            if (s->cursor_guest_mode) {
                s->vga.force_shadow = !!(s->regs.crtc_gen_cntl & CRTC2_CUR_EN);
            } else {
                if (s->regs.crtc_gen_cntl & CRTC2_CUR_EN) {
                    ati_cursor_define(s);
                }
                dpy_mouse_set(s->vga.con, s->regs.cur_hv_pos >> 16,
                                       s->regs.cur_hv_pos & 0xffff,
                                       (s->regs.crtc_gen_cntl & CRTC2_CUR_EN) != 0);
            }
        }
        if ((val & (CRTC2_EXT_DISP_EN | CRTC2_EN)) !=
            (s->regs.crtc_gen_cntl & (CRTC2_EXT_DISP_EN | CRTC2_EN))) {
            ati_vga_switch_mode(s);
        }
        break;
    }
    case CRTC_EXT_CNTL ... CRTC_EXT_CNTL + 3:
    {
        uint32_t val = s->regs.crtc_ext_cntl;
        ati_reg_write_offs(&s->regs.crtc_ext_cntl,
                           addr - CRTC_EXT_CNTL, data, size);
        if (s->regs.crtc_ext_cntl & CRT_CRTC_DISPLAY_DIS) {
            DPRINTF("Display disabled\n");
            s->vga.ar_index &= ~BIT(5);
        } else {
            DPRINTF("Display enabled\n");
            s->vga.ar_index |= BIT(5);
            ati_vga_switch_mode(s);
        }
        if ((val & CRT_CRTC_DISPLAY_DIS) !=
            (s->regs.crtc_ext_cntl & CRT_CRTC_DISPLAY_DIS)) {
            ati_vga_switch_mode(s);
        }
        break;
    }
    case DAC_CNTL:
        s->regs.dac_cntl = data & 0xffffe3ff;
        s->vga.dac_8bit = !!(data & DAC_8BIT_EN);
        break;
    /*
     * GPIO regs for DDC access. Because some drivers access these via
     * multiple byte writes we have to be careful when we send bits to
     * avoid spurious changes in bitbang_i2c state. Only do it when either
     * the enable bits are changed or output bits changed while enabled.
     */
    case GPIO_VGA_DDC ... GPIO_VGA_DDC + 3:
        if (s->dev_id != PCI_DEVICE_ID_ATI_RAGE128_PF) {
            /* FIXME: Maybe add a property to select VGA or DVI port? */
        }
        break;
    case GPIO_DVI_DDC ... GPIO_DVI_DDC + 3:
        if (s->dev_id != PCI_DEVICE_ID_ATI_RAGE128_PF) {
            ati_reg_write_offs(&s->regs.gpio_dvi_ddc,
                               addr - GPIO_DVI_DDC, data, size);
            if ((addr <= GPIO_DVI_DDC + 2 && addr + size > GPIO_DVI_DDC + 2) ||
                (addr == GPIO_DVI_DDC && (s->regs.gpio_dvi_ddc & 0x30000))) {
                s->regs.gpio_dvi_ddc = ati_i2c(&s->bbi2c,
                                               s->regs.gpio_dvi_ddc, 0);
            }
        }
        break;
    case GPIO_MONID ... GPIO_MONID + 3:
        /* FIXME What does Radeon have here? */
        if (s->dev_id == PCI_DEVICE_ID_ATI_RAGE128_PF) {
            /* Rage128p accesses DDC via MONID(1-2) with additional mask bit */
            ati_reg_write_offs(&s->regs.gpio_monid,
                               addr - GPIO_MONID, data, size);
            if ((s->regs.gpio_monid & BIT(25)) &&
                ((addr <= GPIO_MONID + 2 && addr + size > GPIO_MONID + 2) ||
                 (addr == GPIO_MONID && (s->regs.gpio_monid & 0x60000)))) {
                s->regs.gpio_monid = ati_i2c(&s->bbi2c, s->regs.gpio_monid, 1);
            }
        }
        break;
    case PALETTE_INDEX ... PALETTE_INDEX + 3:
        if (size == 4) {
            vga_ioport_write(&s->vga, VGA_PEL_IR, (data >> 16) & 0xff);
            vga_ioport_write(&s->vga, VGA_PEL_IW, data & 0xff);
        } else {
            if (addr == PALETTE_INDEX) {
                vga_ioport_write(&s->vga, VGA_PEL_IW, data & 0xff);
            } else {
                vga_ioport_write(&s->vga, VGA_PEL_IR, data & 0xff);
            }
        }
        break;
    case PALETTE_DATA ... PALETTE_DATA + 3:
        data <<= addr - PALETTE_DATA;
        data = bswap32(data) >> 8;
        vga_ioport_write(&s->vga, VGA_PEL_D, data & 0xff);
        data >>= 8;
        vga_ioport_write(&s->vga, VGA_PEL_D, data & 0xff);
        data >>= 8;
        vga_ioport_write(&s->vga, VGA_PEL_D, data & 0xff);
        break;
    case PALETTE_30_DATA:
        s->regs.palette[vga_ioport_read(&s->vga, VGA_PEL_IW)] = data;
        vga_ioport_write(&s->vga, VGA_PEL_D, (data >> 22) & 0xff);
        vga_ioport_write(&s->vga, VGA_PEL_D, (data >> 12) & 0xff);
        vga_ioport_write(&s->vga, VGA_PEL_D, (data >> 2) & 0xff);
        break;
    case MEM_CNTL:
        s->regs.mem_cntl = data;
        break;
    case CNFG_CNTL:
        s->regs.config_cntl = data;
        break;
    case CRTC_H_TOTAL_DISP ... CRTC_H_TOTAL_DISP + 3:
        ati_reg_write_offs(&s->regs.crtc_h_total_disp,
                           addr - CRTC_H_TOTAL_DISP, data, size);
        s->regs.crtc_h_total_disp &= 0x07ff07ff;
        break;
    case CRTC_H_SYNC_STRT_WID:
        s->regs.crtc_h_sync_strt_wid = data & 0x17bf1fff;
        break;
    case CRTC_V_TOTAL_DISP ... CRTC_V_TOTAL_DISP + 3:
        ati_reg_write_offs(&s->regs.crtc_v_total_disp,
                           addr - CRTC_V_TOTAL_DISP, data, size);
        s->regs.crtc_v_total_disp &= 0x0fff0fff;
        break;
    case CRTC_V_SYNC_STRT_WID:
        s->regs.crtc_v_sync_strt_wid = data & 0x9f0fff;
        break;
    case CRTC_OFFSET:
        s->regs.crtc_offset = data & 0x87fffff8;
        ati_vga_set_offset(&s->vga, s->regs.crtc_offset & 0x07ffffff);
        break;
    case CRTC_OFFSET_CNTL:
        s->regs.crtc_offset_cntl = data; /* FIXME */
        break;
    case CRTC_PITCH:
        data &= 0x07ff07ff;
        if (s->regs.crtc_pitch != data) {
            s->regs.crtc_pitch = data;
            ati_vga_switch_mode(s);
        }
        break;
    case 0xf00 ... 0xfff:
        /* read-only copy of PCI config space so ignore writes */
        break;
    case CUR_OFFSET ... CUR_OFFSET + 3:
    {
        uint32_t t = s->regs.cur_offset;

        ati_reg_write_offs(&t, addr - CUR_OFFSET, data, size);
        t &= 0x87fffff0;
        if (s->regs.cur_offset != t) {
            s->regs.cur_offset = t;
            ati_cursor_define(s);
        }
        break;
    }
    case CUR_HORZ_VERT_POSN ... CUR_HORZ_VERT_POSN + 3:
    {
        uint32_t t = s->regs.cur_hv_pos | (s->regs.cur_offset & BIT(31));

        ati_reg_write_offs(&t, addr - CUR_HORZ_VERT_POSN, data, size);
        s->regs.cur_hv_pos = t & 0x3fff0fff;
        if (t & BIT(31)) {
            s->regs.cur_offset |= t & BIT(31);
        } else if (s->regs.cur_offset & BIT(31)) {
            s->regs.cur_offset &= ~BIT(31);
            ati_cursor_define(s);
        }
        if (!s->cursor_guest_mode &&
            (s->regs.crtc_gen_cntl & CRTC2_CUR_EN) && !(t & BIT(31))) {
            dpy_mouse_set(s->vga.con, s->regs.cur_hv_pos >> 16,
                                   s->regs.cur_hv_pos & 0xffff, true);
        }
        break;
    }
    case CUR_HORZ_VERT_OFF:
    {
        uint32_t t = s->regs.cur_hv_offs | (s->regs.cur_offset & BIT(31));

        ati_reg_write_offs(&t, addr - CUR_HORZ_VERT_OFF, data, size);
        s->regs.cur_hv_offs = t & 0x3f003f;
        if (t & BIT(31)) {
            s->regs.cur_offset |= t & BIT(31);
        } else if (s->regs.cur_offset & BIT(31)) {
            s->regs.cur_offset &= ~BIT(31);
            ati_cursor_define(s);
        }
        break;
    }
    case CUR_CLR0 ... CUR_CLR0 + 3:
    {
        uint32_t t = s->regs.cur_color0;

        ati_reg_write_offs(&t, addr - CUR_CLR0, data, size);
        t &= 0xffffff;
        if (s->regs.cur_color0 != t) {
            s->regs.cur_color0 = t;
            ati_cursor_define(s);
        }
        break;
    }
    case CUR_CLR1 ... CUR_CLR1 + 3:
        /*
         * Update cursor unconditionally here because some clients set up
         * other registers before actually writing cursor data to memory at
         * offset so we would miss cursor change unless always updating here
         */
        ati_reg_write_offs(&s->regs.cur_color1, addr - CUR_CLR1, data, size);
        s->regs.cur_color1 &= 0xffffff;
        ati_cursor_define(s);
        break;
    case DST_OFFSET:
            s->regs.dst_offset = data & 0xfffffff0;
        break;
    case DST_PITCH:
            s->regs.dst_pitch = data & 0x3fff;
        if (s->dev_id == PCI_DEVICE_ID_ATI_RAGE128_PF) {
            s->regs.dst_tile = (data >> 16) & 1;
        }
        break;
    case DST_TILE:
        if (s->dev_id == PCI_DEVICE_ID_ATI_RADEON_QY) {
            s->regs.dst_tile = data & 3;
        }
        break;
    case DST_WIDTH:
        s->regs.dst_width = data & 0x3fff;
        ati_2d_blt(s);
        break;
    case DST_HEIGHT:
        s->regs.dst_height = data & 0x3fff;
        break;
    case SRC_X:
        s->regs.src_x = data & 0x3fff;
        break;
    case SRC_Y:
        s->regs.src_y = data & 0x3fff;
        break;
    case DST_X:
        s->regs.dst_x = data & 0x3fff;
        break;
    case DST_Y:
        s->regs.dst_y = data & 0x3fff;
        break;
    case SRC_PITCH_OFFSET:
        if (s->dev_id == PCI_DEVICE_ID_ATI_RAGE128_PF) {
            s->regs.src_offset = (data & 0x1fffff) << 5;
            s->regs.src_pitch = (data & 0x7fe00000) >> 21;
            s->regs.src_tile = data >> 31;
        } else {
            s->regs.src_offset = (data & 0x3fffff) << 10;
            s->regs.src_pitch = (data & 0x3fc00000) >> 16;
            s->regs.src_tile = (data >> 30) & 1;
        }
        break;
    case DST_PITCH_OFFSET:
    case DST_PITCH_OFFSET_C: {
        uint32_t off, pitch, tile;

        if (s->dev_id == PCI_DEVICE_ID_ATI_RAGE128_PF) {
            off = (data & 0x1fffff) << 5;
            pitch = (data & 0x7fe00000) >> 21;
            tile = data >> 31;
        } else {
            off = (data & 0x3fffff) << 10;
            pitch = (data & 0x3fc00000) >> 16;
            tile = data >> 30;
        }
        /*
         * Keep the two contexts apart. DST_PITCH_OFFSET_C belongs to the
         * 3D setup engine and DST_PITCH_OFFSET to the 2D engine; they are
         * distinct registers the guest programs independently, so folding
         * both into one pair of fields let each engine overwrite the
         * other's render target.
         */
        /*
         * DST_PITCH_OFFSET_C is the CCE context register, not a 3D-only
         * one: 2D blits issued through the command stream (BITBLT_MULTI)
         * program it and then blit, so it must keep feeding the shared 2D
         * state. Routing it away from dst_offset/dst_pitch broke every
         * CCE-driven blit.
         *
         * It additionally keeps a private copy for the 3D rasterizer. The
         * shared fields are still overwritten by plain MMIO writes to
         * DST_PITCH_OFFSET (0x142c) - which Tux Racer does 2353 times with
         * the screen's 4096-byte pitch while the 3D target is 2560 - and
         * that clobbering is what sheared the rendered image. The private
         * copy is only updated from _C, so it survives.
         */
        s->regs.dst_offset = off;
        s->regs.dst_pitch = pitch;
        s->regs.dst_tile = tile;

        if (addr == DST_PITCH_OFFSET_C) {
            s->regs.dst_offset_3d = off;
            s->regs.dst_pitch_3d = pitch;
            s->regs.dst_tile_3d = tile;
        }
        break;
    }
    case SRC_Y_X:
        s->regs.src_x = data & 0x3fff;
        s->regs.src_y = (data >> 16) & 0x3fff;
        break;
    case DST_Y_X:
        s->regs.dst_x = data & 0x3fff;
        s->regs.dst_y = (data >> 16) & 0x3fff;
        break;
    case DST_HEIGHT_WIDTH:
        s->regs.dst_width = data & 0x3fff;
        s->regs.dst_height = (data >> 16) & 0x3fff;
        ati_2d_blt(s);
        break;
    case DP_GUI_MASTER_CNTL:
    case DP_GUI_MASTER_CNTL_C:
        /*
         * The "_C" registers are the context-aperture aliases of the same
         * GUI registers. Accelerated drivers (Mac OS X's among them) program
         * the engine through these rather than the base addresses, so they
         * must have identical side effects - dropping them left the engine
         * with no ROP, no destination datatype and no pitch/offset select.
         */
        s->regs.dp_gui_master_cntl = data & 0xf800000f;
        s->regs.dp_datatype = (data & 0x0f00) >> 8 | (data & 0x30f0) << 4 |
                              (data & 0x4000) << 16;
        s->regs.dp_mix = (data & GMC_ROP3_MASK) | (data & 0x7000000) >> 16;

        if (!(data & GMC_SRC_PITCH_OFFSET_CNTL)) {
            s->regs.src_offset = s->regs.default_offset;
            s->regs.src_pitch = s->regs.default_pitch;
        }
        if (!(data & GMC_DST_PITCH_OFFSET_CNTL)) {
            s->regs.dst_offset = s->regs.default_offset;
            s->regs.dst_pitch = s->regs.default_pitch;
        }
        if (!(data & GMC_SRC_CLIPPING)) {
            s->regs.src_sc_right = s->regs.default_sc_right;
            s->regs.src_sc_bottom = s->regs.default_sc_bottom;
        }
        if (!(data & GMC_DST_CLIPPING)) {
            s->regs.sc_top = 0;
            s->regs.sc_left = 0;
            s->regs.sc_right = s->regs.default_sc_right;
            s->regs.sc_bottom = s->regs.default_sc_bottom;
        }
        break;
    case DST_WIDTH_X:
        s->regs.dst_x = data & 0x3fff;
        s->regs.dst_width = (data >> 16) & 0x3fff;
        ati_2d_blt(s);
        break;
    case SRC_X_Y:
        s->regs.src_y = data & 0x3fff;
        s->regs.src_x = (data >> 16) & 0x3fff;
        break;
    case DST_X_Y:
        s->regs.dst_y = data & 0x3fff;
        s->regs.dst_x = (data >> 16) & 0x3fff;
        break;
    case DST_WIDTH_HEIGHT:
        s->regs.dst_height = data & 0x3fff;
        s->regs.dst_width = (data >> 16) & 0x3fff;
        ati_2d_blt(s);
        break;
    case DST_HEIGHT_Y:
        s->regs.dst_y = data & 0x3fff;
        s->regs.dst_height = (data >> 16) & 0x3fff;
        break;
    case SRC_OFFSET:
            s->regs.src_offset = data & 0xfffffff0;
        break;
    case SRC_PITCH:
            s->regs.src_pitch = data & 0x3fff;
        if (s->dev_id == PCI_DEVICE_ID_ATI_RAGE128_PF) {
            s->regs.src_tile = (data >> 16) & 1;
        }
        break;
    case DP_BRUSH_BKGD_CLR:
        s->regs.dp_brush_bkgd_clr = data;
        break;
    case DP_BRUSH_FRGD_CLR:
        s->regs.dp_brush_frgd_clr = data;
        break;
    case DP_CNTL:
        s->regs.dp_cntl = data;
        break;
    case DP_SRC_FRGD_CLR:
        s->regs.dp_src_frgd_clr = data;
        break;
    case DP_SRC_BKGD_CLR:
        s->regs.dp_src_bkgd_clr = data;
        break;
    case GUI_SCRATCH_REG0 ... GUI_SCRATCH_REG5 + 3:
    {
        int i = (addr - GUI_SCRATCH_REG0) / 4;

        ati_reg_write_offs(&s->regs.gui_scratch[i],
                           addr - (GUI_SCRATCH_REG0 + i * 4), data, size);
        break;
    }
    case DP_DATATYPE:
        s->regs.dp_datatype = data & 0xe0070f0f;
        break;
    case DP_MIX:
        s->regs.dp_mix = data & 0x00ff0700;
        break;
    case DP_WRITE_MASK:
        s->regs.dp_write_mask = data;
        break;
    case DEFAULT_OFFSET:
        if (s->dev_id == PCI_DEVICE_ID_ATI_RAGE128_PF) {
            s->regs.default_offset = data & 0xfffffff0;
        } else {
            /* Radeon has DEFAULT_PITCH_OFFSET here like DST_PITCH_OFFSET */
            s->regs.default_offset = (data & 0x3fffff) << 10;
            s->regs.default_pitch = (data & 0x3fc00000) >> 16;
            s->regs.default_tile = data >> 30;
        }
        break;
    case DEFAULT_PITCH:
        if (s->dev_id == PCI_DEVICE_ID_ATI_RAGE128_PF) {
            s->regs.default_pitch = data & 0x3fff;
            s->regs.default_tile = (data >> 16) & 1;
        }
        break;
    case DEFAULT_SC_BOTTOM_RIGHT:
        s->regs.default_sc_right = data & 0x3fff;
        s->regs.default_sc_bottom = (data >> 16) & 0x3fff;
        break;
    case TEX_CNTL_C:
        s->regs.tex_cntl = data;
        break;
    case PRIM_TEX_CNTL_C:
        s->regs.prim_tex_cntl = data;
        break;
    case PRIM_TEXTURE_COMBINE_CNTL_C:
        s->regs.prim_tex_combine = data;
        break;
    case TEX_SIZE_PITCH_C:
        s->regs.tex_size_pitch = data;
        break;
    case PRIM_TEX_0_OFFSET_C ... PRIM_TEX_0_OFFSET_C + 10 * 4:
        /*
         * Eleven consecutive mip-level offsets. The driver bursts all of
         * them in one packet0 write (CCE_PACKET0 with count
         * 2 + R128_MAX_TEXTURE_LEVELS), so they arrive as a run of
         * auto-incrementing register writes.
         */
        s->regs.prim_tex_offset[(addr - PRIM_TEX_0_OFFSET_C) / 4] = data;
        break;
    case MISC_3D_STATE_CNTL_REG_C:
        s->regs.misc_3d_state = data;
        break;
    case Z_OFFSET_C:
        s->regs.z_offset = data;
        break;
    case Z_PITCH_C:
        s->regs.z_pitch = data;
        break;
    case Z_STEN_CNTL_C:
        s->regs.z_sten_cntl = data;
        break;
    case SEC_TEX_CNTL_C:
        s->regs.sec_tex_cntl = data;
        break;
    case SEC_TEX_COMBINE_CNTL_C:
        s->regs.sec_tex_combine = data;
        break;
    case SEC_TEX_0_OFFSET_C ... SEC_TEX_0_OFFSET_C + 10 * 4:
        s->regs.sec_tex_offset[(addr - SEC_TEX_0_OFFSET_C) / 4] = data;
        break;
    case PC_GUI_CTLSTAT:
    case PC_NGUI_CTLSTAT:
        /* Flush requests complete immediately; keep the bits, drop BUSY. */
        s->regs.pc_gui_ctlstat = data & ~PC_BUSY;
        break;
    case SETUP_CNTL:
        s->regs.setup_cntl = data;
        break;
    case PM4_VC_FPU_SETUP:
        s->regs.vc_fpu_setup = data;
        break;
    case SC_TOP_LEFT:
    case SC_TOP_LEFT_C:
        s->regs.sc_left = data & 0x3fff;
        s->regs.sc_top = (data >> 16) & 0x3fff;
        break;
    case SC_LEFT:
        s->regs.sc_left = data & 0x3fff;
        break;
    case SC_TOP:
        s->regs.sc_top = data & 0x3fff;
        break;
    case SC_BOTTOM_RIGHT:
    case SC_BOTTOM_RIGHT_C:
        s->regs.sc_right = data & 0x3fff;
        s->regs.sc_bottom = (data >> 16) & 0x3fff;
        break;
    case SC_RIGHT:
        s->regs.sc_right = data & 0x3fff;
        break;
    case SC_BOTTOM:
        s->regs.sc_bottom = data & 0x3fff;
        break;
    case SRC_SC_BOTTOM_RIGHT:
        s->regs.src_sc_right = data & 0x3fff;
        s->regs.src_sc_bottom = (data >> 16) & 0x3fff;
        break;
    case SRC_SC_RIGHT:
        s->regs.src_sc_right = data & 0x3fff;
        break;
    case SRC_SC_BOTTOM:
        s->regs.src_sc_bottom = data & 0x3fff;
        break;
    case PCI_GART_PAGE:
        /* Guest-physical address of the GART page table. */
        s->regs.pci_gart_page = data;
        break;
    case MC_AGP_LOCATION:
        s->regs.mc_agp_location = data;
        break;
    case MC_FB_LOCATION:
        s->regs.mc_fb_location = data;
        break;
    case PM4_IW_INDOFF:
        /* Offset of the next indirect buffer within the GART aperture. */
        s->cce.iw_indoff = data;
        break;
    case PM4_IW_INDSIZE:
        /*
         * Length in dwords, and the trigger: writing INDSIZE makes the
         * engine fetch and execute the buffer INDOFF points at.
         *
         * Passed through unmasked. Earlier attempts to mask or strip bits
         * here - a flat 12-bit field, then clearing the top set bit - both
         * truncated real work. glxgears submits buffers of 0x1470 (5232)
         * dwords; stripping pow2floor(5232) executes only 1136 of them,
         * which left it drawing one gear instead of three. The kernel
         * panic those masks were chasing had a different cause entirely
         * (texture uploads DMAing over the driver's command buffers), and
         * the size cap inside ati_cce_exec_indirect is guard enough.
         */
        ati_cce_exec_indirect(s, data);
        break;
    case PM4_FIFO_DATA_EVEN:
    case PM4_FIFO_DATA_ODD:
        /*
         * Both ports feed a single command stream; the driver alternates
         * between them.  Hand each dword to the PIO packet decoder.
         */
        ati_cce_fifo_write(s, data);
        break;
    case PM4_BUFFER_OFFSET:
        s->cce.buffer_offset = data & 0x03fffff0;
        break;
    case PM4_BUFFER_CNTL:
        s->cce.buffer_cntl = data;
        break;
    case PM4_BUFFER_DL_RPTR:
        /* Same as the write pointer below: low bits only, bit 31 is a flag. */
        s->cce.rptr = (data & 0x3fffff) % PM4_192PIO_RING_DWORDS;
        break;
    case PM4_BUFFER_DL_WPTR:
        /*
         * Only the low bits are the ring position; bit 31 is a flag, not
         * part of the pointer. The driver writes 0x80000000 here (six
         * times in one Tux Racer capture, alongside seven writes of 0)
         * when tearing the engine down. Storing it verbatim made
         * ati_cce_process() walk from rptr toward a write pointer of
         * 2147483648, decoding megabytes of unrelated memory as packets -
         * which is where the 425 phantom packet3 opcodes (0xff, 0x8f,
         * 0x03) and the "exceeded max iterations" bailouts came from.
         * Those counts were identical across runs regardless of any
         * indirect-buffer change, which is what showed they came from the
         * ring rather than from indirect buffers.
         */
        s->cce.wptr = (data & 0x3fffff) % PM4_192PIO_RING_DWORDS;
        ati_cce_process(s);
        break;
    case PM4_VC_FORMAT:
        s->cce.vc_format = data;
        break;
    case PM4_VC_CNTL:
        s->cce.vc_cntl = data;
        break;
    default:
        break;
    }
}

static const MemoryRegionOps ati_mm_ops = {
    .read = ati_mm_read,
    .write = ati_mm_write,
    .endianness = DEVICE_LITTLE_ENDIAN,
};

static void ati_vga_realize(PCIDevice *dev, Error **errp)
{
    ATIVGAState *s = ATI_VGA(dev);
    VGACommonState *vga = &s->vga;
    I2CBus *i2cbus;

#ifndef CONFIG_PIXMAN
    if (s->use_pixman != 0) {
        warn_report("x-pixman != 0, not effective without PIXMAN");
    }
#endif

    if (s->model) {
        int i;
        for (i = 0; i < ARRAY_SIZE(ati_model_aliases); i++) {
            if (!strcmp(s->model, ati_model_aliases[i].name)) {
                s->dev_id = ati_model_aliases[i].dev_id;
                break;
            }
        }
        if (i >= ARRAY_SIZE(ati_model_aliases)) {
            warn_report("Unknown ATI VGA model name, "
                        "using default rage128p");
        }
    }
    if (s->dev_id != PCI_DEVICE_ID_ATI_RAGE128_PF &&
        s->dev_id != PCI_DEVICE_ID_ATI_RADEON_QY) {
        error_setg(errp, "Unknown ATI VGA device id, "
                   "only 0x5046 and 0x5159 are supported");
        return;
    }
    pci_set_word(dev->config + PCI_DEVICE_ID, s->dev_id);

    if (s->dev_id == PCI_DEVICE_ID_ATI_RADEON_QY &&
        s->vga.vram_size_mb < 16) {
        warn_report("Too small video memory for device id");
        s->vga.vram_size_mb = 16;
    }

    /* init vga bits */
    if (!vga_common_init(vga, OBJECT(s), errp)) {
        return;
    }
    vga_init(vga, OBJECT(s), pci_address_space(dev),
             pci_address_space_io(dev), true);
    vga->con = graphic_console_init(DEVICE(s), 0, s->vga.hw_ops, vga);
    if (s->cursor_guest_mode) {
        vga->cursor_invalidate = ati_cursor_invalidate;
        vga->cursor_draw_line = ati_cursor_draw_line;
    }

    /* ddc, edid */
    i2cbus = i2c_init_bus(DEVICE(s), "ati-vga.ddc");
    bitbang_i2c_init(&s->bbi2c, i2cbus);
    i2c_slave_set_address(I2C_SLAVE(&s->i2cddc), 0x50);
    qdev_realize(DEVICE(&s->i2cddc), BUS(i2cbus), &error_abort);

    /* mmio register space */
    memory_region_init_io(&s->mm, OBJECT(s), &ati_mm_ops, s,
                          "ati.mmregs", 0x4000);
    /* io space is alias to beginning of mmregs */
    memory_region_init_alias(&s->io, OBJECT(s), "ati.io", &s->mm, 0, 0x100);

    /*
     * The framebuffer is at the beginning of the linear aperture. For
     * Rage128 the upper half of the aperture is reserved for an AGP
     * window (which we do not emulate.)
     */
    if (!s->linear_aper_sz) {
        if (s->dev_id == PCI_DEVICE_ID_ATI_RAGE128_PF) {
            s->linear_aper_sz = ATI_RAGE128_LINEAR_APER_SIZE;
        } else {
            s->linear_aper_sz = ATI_R100_LINEAR_APER_SIZE;
        }
    }
    if (s->linear_aper_sz > 256 * MiB) {
        error_setg(errp, "x-linear-aper-size is too large (maximum 256 MiB)");
        return;
    }
    if (s->linear_aper_sz < 16 * MiB) {
        error_setg(errp, "x-linear-aper-size is too small (minimum 16 MiB)");
        return;
    }
    memory_region_init(&s->linear_aper, OBJECT(dev), "ati-linear-aperture0",
                       s->linear_aper_sz);
    memory_region_add_subregion(&s->linear_aper, 0, &vga->vram);
    /*
     * The Rage128 linear BAR is split into two equal apertures: aperture 0 at
     * the BAR base and aperture 1 at base + size/2.  Both address the same
     * video memory; on real hardware they differ only in the byte-swapping
     * selected by CNFG_CNTL (APER_0_ENDIAN / APER_1_ENDIAN), which is already
     * handled in software via vga.big_endian_fb.
     *
     * Only aperture 0 was mapped, so a guest that uses aperture 1 - which the
     * Mac OS X PowerPC driver does, because it wants the byte-swapped view -
     * wrote its entire framebuffer into unassigned memory.  Those writes were
     * silently discarded: the display never changed and no VGA dirty pages
     * were ever recorded.  Alias the same VRAM into aperture 1 so the writes
     * land in video memory and mark it dirty.
     */
    memory_region_init_alias(&s->linear_aper1, OBJECT(dev),
                             "ati-linear-aperture1", &vga->vram, 0,
                             vga->vram_size);
    memory_region_add_subregion(&s->linear_aper, s->linear_aper_sz / 2,
                                &s->linear_aper1);

    pci_register_bar(dev, 0, PCI_BASE_ADDRESS_MEM_PREFETCH, &s->linear_aper);
    pci_register_bar(dev, 1, PCI_BASE_ADDRESS_SPACE_IO, &s->io);
    pci_register_bar(dev, 2, PCI_BASE_ADDRESS_SPACE_MEMORY, &s->mm);

    /* most interrupts are not yet emulated but MacOS needs at least VBlank */
    dev->config[PCI_INTERRUPT_PIN] = 1;
    timer_init_ns(&s->vblank_timer, QEMU_CLOCK_VIRTUAL, ati_vga_vblank_irq, s);
}

static void ati_vga_reset(DeviceState *dev)
{
    ATIVGAState *s = ATI_VGA(dev);

    timer_del(&s->vblank_timer);
    ati_vga_update_irq(s);

    /* reset vga */
    vga_common_reset(&s->vga);
    s->mode = VGA_MODE;

    s->host_data.active = false;
    s->host_data.next = 0;
    s->host_data.row = 0;
    s->host_data.col = 0;

    /*
     * Default the 2D blit direction to left-to-right, top-to-bottom.
     *
     * DP_CNTL selects the direction the engine walks a blit, and ati_2d_blt
     * treats a cleared DST_X_LEFT_TO_RIGHT / DST_Y_TOP_TO_BOTTOM as "walk
     * backwards", which also means the supplied DST_X/DST_Y name the bottom
     * right corner rather than the top left.
     *
     * Leaving the register at zero out of reset made that the default, but
     * drivers that only ever program the forward direction never write
     * DP_CNTL at all - Mac OS X's accelerated Rage128 driver does not touch
     * it once. Every blit was then treated as reversed: coordinates were
     * rebased to dst - (size - 1), which for a full-screen blit at (0,0)
     * underflows to a huge unsigned value and trips the bounds check, so the
     * blit was dropped outright.
     */
    s->regs.dp_cntl = DST_X_LEFT_TO_RIGHT | DST_Y_TOP_TO_BOTTOM;
}

static void ati_vga_exit(PCIDevice *dev)
{
    ATIVGAState *s = ATI_VGA(dev);

    timer_del(&s->vblank_timer);
    graphic_console_close(s->vga.con);
}

static const Property ati_vga_properties[] = {
    DEFINE_PROP_UINT32("vgamem_mb", ATIVGAState, vga.vram_size_mb, 16),
    DEFINE_PROP_STRING("model", ATIVGAState, model),
    DEFINE_PROP_UINT16("x-device-id", ATIVGAState, dev_id,
                       PCI_DEVICE_ID_ATI_RAGE128_PF),
    DEFINE_PROP_BOOL("guest_hwcursor", ATIVGAState, cursor_guest_mode, false),
    /* this is a debug option, prefer PROP_UINT over PROP_BIT for simplicity */
    DEFINE_PROP_UINT8("x-pixman", ATIVGAState, use_pixman, DEFAULT_X_PIXMAN),
    DEFINE_PROP_UINT64("x-linear-aper-size", ATIVGAState, linear_aper_sz, 0),
    DEFINE_EDID_PROPERTIES(ATIVGAState, i2cddc.edid_info),
};

static void ati_vga_class_init(ObjectClass *klass, void *data)
{
    DeviceClass *dc = DEVICE_CLASS(klass);
    PCIDeviceClass *k = PCI_DEVICE_CLASS(klass);

    device_class_set_legacy_reset(dc, ati_vga_reset);
    device_class_set_props(dc, ati_vga_properties);
    dc->hotpluggable = false;
    set_bit(DEVICE_CATEGORY_DISPLAY, dc->categories);

    k->class_id = PCI_CLASS_DISPLAY_VGA;
    k->vendor_id = PCI_VENDOR_ID_ATI;
    k->device_id = PCI_DEVICE_ID_ATI_RAGE128_PF;
    k->romfile = "vgabios-ati.bin";
    k->realize = ati_vga_realize;
    k->exit = ati_vga_exit;
}

static void ati_vga_init(Object *o)
{
    ATIVGAState *s = ATI_VGA(o);

    object_initialize_child(o, "edid", &s->i2cddc, TYPE_I2CDDC);
    object_property_set_description(o, "x-pixman", "Use pixman for: "
                                    "1: fill, 2: blit");
}

static const TypeInfo ati_vga_info = {
    .name = TYPE_ATI_VGA,
    .parent = TYPE_PCI_DEVICE,
    .instance_size = sizeof(ATIVGAState),
    .class_init = ati_vga_class_init,
    .instance_init = ati_vga_init,
    .interfaces = (InterfaceInfo[]) {
          { INTERFACE_CONVENTIONAL_PCI_DEVICE },
          { },
    },
};

static void ati_vga_register_types(void)
{
    type_register_static(&ati_vga_info);
}

type_init(ati_vga_register_types)
